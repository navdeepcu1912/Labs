//
//  ViewController.swift
//  PersonalityQuiz
//
//  Created by Student on 23/07/25.
//

import UIKit

class IntroductionViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func unwindToIntro(segue: UIStoryboardSegue){}


}

