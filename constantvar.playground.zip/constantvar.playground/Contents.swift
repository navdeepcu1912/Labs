import UIKit

//activity one
//Exercise - constants
//
//let friends = 555
//print("I have \(friends) friends")
//
////friends = 500
//
//print("Gives Error tells to change the let keyword to var to make it a variable")
//
//// Exercise Step Goal
//
//let goalSteps = 10000
//
//print("Your step goal for the day is:")
//print(goalSteps)
//
////Exercise Variables
//
//var schooling = 15
//print(schooling)
//
//schooling = schooling + 1
//print(schooling)
//
//print("The above code for the exercise variable gets compiled beacuse when we use var keyword we can update the value of variable")
//
////App Exercise - Step Count
//
//var steps = 0
//print(steps)
//
//steps = 2000
//
//print("Steps Covered \(steps) Good job! You're well on your way to your daily goal.")
// 

//Ex 5
var noOfLikes = 150
var noOfComments = 45
let yearOfcreation = 2021
let monthOfcreation = 2
let dayOfcreation = 24

//Ex 6

let name = "Sunny"
var age = 30
var noOfsteps = 10
let goalOfSteps = 10000
let avgHeartRate = 70

//Ex 7

var firstDecimal = 0.9
var secondDecimal = 0.7

var trueOrFalse = false
//firstDecimal = trueOrFalse
print("Error: cannot assign bool to decimal")

var sampleString = "Hello"
//firstDecimal = sampleString
//print("Error again says cant assign string to decimal")
var wholeno = 5
//wholeno = secondDecimal
print("Again gives error cannot assign decimal to type Int")

var hasMetStepGoal = false
var noofSteps = 10_000
print(noofSteps)


print(12.7+3)


  
let x : Int = 51
let y : Double = 2
//print(x/y)

//print(x+y)

//var nam : String = "Navi"
//print(nam)

var distanceTravelled = 0

//distanceTravelled = 54.3
var sample = 43.33
sample += 2
print(sample)

//var percentCompleted : Double = 0


