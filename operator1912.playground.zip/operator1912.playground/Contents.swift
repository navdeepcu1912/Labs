import UIKit

//Operators Assignment

let width = 10
let height = 20
let area_shed = width*height
print(area_shed)


let roomArea = area_shed/2
print("divided area: \(roomArea)")

let perimeter = width + height + width + height
print(perimeter)

let double10 = 10
let double3 = 3
let divisionResult = 10/3
print(divisionResult)

let radius = 5.0
let diameter = 2*radius
let pi=3.1415927
let circumference = 2 * pi * radius
//print(circumference,diameter)

let even : Int = 2
let odd :Int = 33

//print(even/2)
//print(odd/2)

let heartRate1 = 65
let heartRate2 = 76
let hearRate3=99
let addedHR=heartRate1+heartRate2+hearRate3
let averageHR = addedHR/3

print("AverageHR",averageHR)

let heartRate1D : Double = 65
let heartRate2D : Double = 76
let heartRate3D : Double = 99
let addedHRD : Double = heartRate1D+heartRate2D+heartRate3D
let averageHRD : Double = addedHRD/3
print(averageHRD)


print()
//2
let steps_ex2 : Double = 3467
let goal:Double = 10_000
let percentOfGoal = (steps_ex2/goal)*100
print(percentOfGoal)

var var1 = 10
print(var1)
var1+=5
print(var1)
var1*=2
print(var1)


print()
// 3
 var piggyBank = 0
piggyBank+=10
print(piggyBank)
piggyBank+=20
print(piggyBank)
piggyBank/=2
print(piggyBank)
piggyBank*=3
print(piggyBank)
piggyBank-=3
print(piggyBank)


print()

//4

var steps_4ex = 0
steps_4ex+=1


var distance_travelled_4ex : Double = 50
print("Distance Travelled in meteres ",distance_travelled_4ex/3,"meters")

// 5

print()

print(10+2*5)

print((10+2)*5)

print(4*9-6/2)

print(4*(9-6)/2)

//6
print()

let hrate1 : Double = 60
let hrate2 : Double = 76
let hrate3 : Double = 97

let avg_hrate = (hrate1+hrate2+hrate3)/3
print(avg_hrate)

print()

let tempInFarenheit = 98.6

let tempInCelsius = (tempInFarenheit-32)*(5.0/9.0)
print(tempInCelsius)

print()

// 7

let x_ex7 : Int = 10
let y_ex7 : Double = 3.2
let multipliedAsIntegers = x_ex7*Int(y_ex7)
print(multipliedAsIntegers)

let multipliedAsDoubles = Double(x_ex7)*y_ex7
print(multipliedAsDoubles)

print("These expressions have been converted explicitly to ensure correct results")


//8

var steps_8ex : Int = 5000
var goal_8ex : Int = 10_000
var percentOfGoal_8ex : Double = (Double(steps_8ex)/Double(goal_8ex))*100
print(percentOfGoal_8ex)
